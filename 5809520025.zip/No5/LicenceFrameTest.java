//5809520025 kuntakarn marlaidang
package No5;

public class LicenceFrameTest {

	public static void main(String[] args) {
		new LicenceFrame();

	}

}
