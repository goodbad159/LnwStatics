//5809520025 kuntakarn marlaidang
package No5;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class LicenceFrame extends JFrame {
	private JTextField jtf1;
	private JTextField jtf2;
	private JTextField jtf3;
	private JButton add;
	private JTextArea jta;

	public LicenceFrame() {
		setTitle("License Plate Info");

		JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(4, 0));

		JPanel jp_1 = new JPanel();
		jp_1.setLayout(new BorderLayout());
		JPanel jp1_1 = new JPanel();
		JLabel jl1 = new JLabel("License Plate :");
		jl1.setHorizontalAlignment(JLabel.LEFT);
		jtf1 = new JTextField(10);
		jp1_1.add(jl1);
		jp1_1.add(jtf1);
		jp_1.add(jp1_1, BorderLayout.WEST);

		JPanel jp_2 = new JPanel();
		jp_2.setLayout(new BorderLayout());
		JPanel jp1_2 = new JPanel();
		JLabel jl2 = new JLabel("Name Lastname :");
		jl2.setHorizontalAlignment(JLabel.LEFT);
		jtf2 = new JTextField(30);
		jp1_2.add(jl2);
		jp1_2.add(jtf2);
		jp_2.add(jp1_2, BorderLayout.WEST);

		JPanel jp_3 = new JPanel();
		jp_3.setLayout(new BorderLayout());
		JPanel jp1_3 = new JPanel();
		JLabel jl3 = new JLabel("Phone No :");
		jl3.setHorizontalAlignment(JLabel.LEFT);
		jtf3 = new JTextField(20);
		jp1_3.add(jl3);
		jp1_3.add(jtf3);
		jp_3.add(jp1_3, BorderLayout.WEST);

		JPanel jp1_4 = new JPanel();
		add = new JButton("Add");
		jp1_4.add(add);

		jta = new JTextArea(10, 30);

		jp1.add(jp_1);
		jp1.add(jp_2);
		jp1.add(jp_3);
		jp1.add(jp1_4);

		add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String s1 = "^[A-Z]{1,3}-\\d{4}$";
				String s2 = "^[A-Z]{1}[a-z\\d-]{1,9}[\" \"]{1,}[A-Z]{1}[a-z\\d\" \"-]{1,19}$";
				String s3 = "0[89]\\d{8}$|^0[89]-\\d{8}$|^0[89]-\\d{4}-\\d{4}$";
				String word = "";
				if (jtf1.getText().matches(s1) && jtf2.getText().matches(s2) && jtf3.getText().matches(s3)) {
					word+=jtf1.getText()+"\t"+jtf2.getText()+"\t"+jtf3.getText()+"\n";
				}if(jtf1.getText().matches(s1)==false){
					JOptionPane.showMessageDialog(null, "Licencs Plate is invalid");
				}if(jtf2.getText().matches(s2)==false){
					JOptionPane.showMessageDialog(null, "Name/Lastname is invalid");
				}if(jtf3.getText().matches(s3)==false){
					JOptionPane.showMessageDialog(null, "Telephone is invalid");
				}
				jta.append(word);
			}
		});

		add(jp1, BorderLayout.NORTH);
		add(jta, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		pack();
	}
}
