//5809520025 kuntakarn marlaidang
package No1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.PaintContext;
import java.awt.geom.Arc2D;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JPanel;

public class VoterPanel extends JPanel {
	private double sta;
	private double sto;
	private Voter v;
	private ArrayList<Color> color;

	public VoterPanel(File f) {
		setPreferredSize(new Dimension(200, 200));
		sta = 0;
		sto = 0;
		v = new Voter(f);
		v.addPlist();
		color = new ArrayList<>();
		color.add(Color.cyan);
		color.add(Color.red);
		color.add(Color.blue);
		color.add(Color.green);
		color.add(Color.ORANGE);
		color.add(Color.YELLOW);
		color.add(Color.GRAY);
		color.add(Color.LIGHT_GRAY);
		color.add(Color.BLACK);
		color.add(Color.MAGENTA);
		// setBackground(Color.getHSBColor((float)0.9,(float) 0.8, (float)0.7));
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		double ra = 3.6;
		Graphics2D g2 = (Graphics2D) g;
		try{
		for (int i = 0; i < v.getPic(); i++) {
			g2.setColor(color.get(i));
			if (i == 0) {
				sta = 90;
				sto = v.getPer()[i] * ra;
			} else {
				sta = sta - sto;
				sto = v.getPer()[i] * ra;
			}
			Arc2D.Float a = new Arc2D.Float(20, 20, getWidth() - 40, getWidth() - 40, (float) (sta), -(float) (sto),
					Arc2D.PIE);
			g2.fill(a);
			repaint();
		}}catch(Exception ex){
			
		}

	}

	public String getDData() {
		String dData = v.printlList() + "\n" + v.printStatis();
		return dData;
	}
}
