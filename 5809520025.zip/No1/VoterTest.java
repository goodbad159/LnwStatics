//5809520025 kuntakarn marlaidang
package No1;

public class VoterTest {

	public static void main(String[] args) {
		VoterFrame j= new VoterFrame();
	}

}
