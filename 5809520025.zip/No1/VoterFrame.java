//5809520025 kuntakarn marlaidang
package No1;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class VoterFrame extends JFrame {
	private JTextArea l;
	private VoterPanel r;
	private JMenuItem open;
	private JMenuItem exit;
	private Voter v; 
	private VoterPanel vp;
	private int mm;

	public VoterFrame() {
		setLayout(new GridLayout(0, 2));
		setSize(660, 400);
		mm=0;
		JMenuBar jmb = new JMenuBar();
		JMenu jm = new JMenu("File");
		open = new JMenuItem("Open");
		exit = new JMenuItem("Exit");
		jm.add(open);
		jm.add(exit);
		jmb.add(jm);
		setJMenuBar(jmb);

		l = new JTextArea(20, 25);
		JScrollPane jcpl = new JScrollPane(l);
		add(jcpl);

		open.addActionListener(new ActionListener() {
			private JFileChooser ch;
			private File f;
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(mm>0){
					remove(r);
				}
				l.setText("");
				ch = new JFileChooser();
				int op = ch.showOpenDialog(null);
				if (op == JFileChooser.APPROVE_OPTION) {
					f = ch.getSelectedFile();
					r = new VoterPanel(f);
					l.setText(r.getDData());
				}
				mm++;
				add(r);
				validate();
			}
		});
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
				
			}
		});
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		//pack();
	}

}
