//5809520025 kuntakarn marlaidang
package No1;

import java.io.File;
import java.util.ArrayList;

public class Voter {
	private ArrayList<String> plist;
	private ArrayList<String> nlist;
	private ArrayList<String> pslist;
	private VoterSet vs;
	private double[] per;
	private int n;
	private String ss;

	public Voter(File file) {
		n = 0;
		vs = new VoterSet(file);
		plist = new ArrayList<>();
		nlist = new ArrayList<>();
		pslist = new ArrayList<>();
	}

	public void addPlist() {
		String[] data = vs.getData().split("\n");
		for (String d : data) {
			plist.add(d);
		}
		for (int i = 0; i < plist.size(); i++) {

			String[] num = plist.get(i).split(" :");
			pslist.add(num[0]);
			try {
				addNlist(num[1]);
			} catch (Exception e) {
				ss = "";
			}
		}

	}

	public void addNlist(String data) {
		nlist.add(data);
	}

	public String printlList() {
		String data = "";
		try {
			for (int i = 0; i < plist.size(); i++) {
				data += pslist.get(i) + "	votes for team:" + nlist.get(i) + "\n";
			}
		} catch (Exception e) {
			ss = "";
		}
		return data;
	}

	public String printStatis() {
		int[] number = new int[vs.getMax()];
		for (int i = 0; i < number.length; i++) {
			number[i] = 0;
		}
		int n = (vs.getMax() - vs.getMin()) + 1;
		int[] num = new int[n];
		for (int i = 0; i < num.length; i++) {
			num[i] = 0;
		}
		for (int i = 0; i < number.length; i++) {
			for (int j = 0; j < nlist.size(); j++) {
				int nn = Integer.parseInt(nlist.get(j));
				if ((i + 1) == nn) {
					number[i]++;
				}
			}
		}
		try {
			for (int i = 0; i < num.length; i++) {
				num[i] = number[i + (vs.getMin() - 1)];
			}
			ss = "	------------Statistics------------" + "\n	" + "Team 	     " + "Score       " + "Percent(%)"
					+ "\n";
			per = new double[num.length];
			for (int i = 0; i < num.length; i++) {
				per[i] = (100.00 / nlist.size()) * num[i];
				ss += "	" + (i + 1) + " 	     " + num[i] + "               " + String.format("%.2f", per[i]) + "\n";
			}
		} catch (Exception e) {
			ss = "";
		}
		return ss;
	}

	public double[] getPer() {
		return per;
	}

	public int getPic() {
		n = (vs.getMax() - vs.getMin()) + 1;
		return n;
	}
}
