//5809520025 kuntakarn marlaidang
package No1;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

public class VoterSet {
	private HashSet<String> plist;
	private String data;
	private String numTeam = "";
	private int min=0,max=0;

	public VoterSet(File file) {
		plist = new HashSet<>();
		this.data = "";
		try {
			FileReader fr = new FileReader(file);
			BufferedReader brd = new BufferedReader(fr);
			String s1 = brd.readLine();
			String s2 = "";
			String s3 = "\n";
			for (; s1 != null;) {
				s2 += s1 + s3;
				s1 = brd.readLine();
			}
			String[] p = s2.split("\n");
			numTeam = p[0];
			String[] bn = numTeam.split(" ");
			try{
				min = Integer.valueOf(bn[0]);
				max = Integer.valueOf(bn[1]);
				for (int i = 1; i < p.length; i++) {
					setData(p[i]);
				}
				brd.close();
			}catch(Exception e){
				
			}
		} catch (IOException io) {

		}
	}

	public void setData(String data) {
		try {
			if (data.charAt(0) != '#') {
				String[] s1 = data.split("#");
				boolean p = plist.add(s1[0]);
				if (Integer.valueOf(s1[1]) <= getMax()) {
					if (p == true) {
						this.data += s1[0] + " :" + s1[1] + "\n";
					}
				} else {
					System.out.println("Skip the line content- Invalid team number vote.:  " + data);
				}

			} else {
				System.out.println("Skip the line content- Invalid voter's name.:  " + data);
			}
		} catch (Exception e) {
			System.out.println("Skip the line content- Invalid length of voter.:  " + data);
		}
	}

	public String getData() {
		return data;
	}

	public int getMin() {
		return min;
	}

	public int getMax() {
		return max;
	}

}
