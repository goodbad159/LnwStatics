//5809520025 kuntakarn marlaidang
package No4;
import java.util.Comparator;
import java.util.PriorityQueue;

public class GameString implements Comparable<GameString> {
	protected String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public GameString(String content) {
		this.content = content;
	}

	public boolean equals(Object obj) {
		return true;
	}

	@Override
	public int compareTo(GameString o) {
		int r=0;
		if(this.getContent().equalsIgnoreCase(o.getContent())){
			return 1;
		}else if(!this.getContent().equalsIgnoreCase(o.getContent())){
			return -1;
		}
		return r;
	}

}
