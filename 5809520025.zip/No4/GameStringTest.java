//5809520025 kuntakarn marlaidang
package No4;

public class GameStringTest {

	public static void main(String[] args) {
		new GameStringFrame();
	}
}
