//5809520025 kuntakarn marlaidang
package No4;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.PriorityQueue;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GameStringFrame extends JFrame {
	private JButton load,start,add;
	private JTextArea jta;
	private JTextField jtf;
	private PriorityQueue<String> queue;
	private GameString game;
	
	public GameStringFrame(){
		queue = new PriorityQueue<>();
		JPanel jp1 = new JPanel();
		load = new JButton("Load");
		start = new JButton("Start");
		jp1.add(load);
		jp1.add(start);
		start.setEnabled(false);
		
		jta = new JTextArea(10,25);
		jta.setWrapStyleWord(true);
		
		JPanel jp3 = new JPanel();
		jtf = new JTextField(10);
		jtf.setEditable(false);
		add = new JButton("Add");
		add.setEnabled(false);
		jp3.add(jtf);
		jp3.add(add);
		
		load.addActionListener(new ActionListener() {
			private JFileChooser ch;
			private File file;
			@Override
			public void actionPerformed(ActionEvent arg0) {
				start.setEnabled(true);
				ch = new JFileChooser();
				int op = ch.showOpenDialog(null);
				if(op==JFileChooser.APPROVE_OPTION){
					file = ch.getSelectedFile();
					try {
						FileReader fr = new FileReader(file);
						BufferedReader bfr = new BufferedReader(fr);
						String s = bfr.readLine();
						game = new GameString(s);
						for(;s!=null;){
							game.setContent(s);
							if(game.compareTo(game)>1){
								queue.add(game.getContent());
							}
							s = bfr.readLine();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					
				}
				
			}
		});
		start.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jtf.setEditable(true);
				add.setEnabled(true);
			}
		});
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
		        while (queue.peek() != null){
		            if(queue.peek().equalsIgnoreCase(jtf.getText())){
		            	jta.setText(jtf.getText());
		            }
		        }
			}
		});
		
		add(jp1,BorderLayout.NORTH);
		add(jta,BorderLayout.CENTER);
		add(jp3,BorderLayout.SOUTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		pack();
	}
}	
