//5809520025 kuntakarn marlaidang
package No3;

public class BinaryStringGeneratorTast {

	public static void main(String[] args) {
		System.out.println(BinaryStringGenerator.genBinaryString(4));
		System.out.println(BinaryStringGenerator.genBinaryString(7));
	}

}
