//5809520025 kuntakarn marlaidang
package No3;
import java.util.LinkedList;
import java.util.Queue;

public class BinaryStringGenerator {
	private static Queue<String> numlist;

	public static String genBinaryString(int num) {
		numlist = new LinkedList<String>();
		String groupNum = "";
		numlist.add(1 + "");
		for (int i = 1; i <= num; i++) {
			String s2 = numlist.poll();
			groupNum += s2 + " ";
			String s3 = s2 + "0";
			String s4 = s2 + "1";
			numlist.add(s3);
			numlist.add(s4);
		}
		return groupNum;
	}
}
